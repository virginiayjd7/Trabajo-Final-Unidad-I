﻿using System;

namespace ProyecttoSysFerreteria
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}
