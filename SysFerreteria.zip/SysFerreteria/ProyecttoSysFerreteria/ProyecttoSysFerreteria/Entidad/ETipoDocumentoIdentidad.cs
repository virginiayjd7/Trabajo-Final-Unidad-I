﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ProyecttoSysFerreteria.Entidad;

namespace ProyecttoSysFerreteria.Entidad
{
    public class ETipoDocumentoIdentidad:ETabla
    {
    }
}
