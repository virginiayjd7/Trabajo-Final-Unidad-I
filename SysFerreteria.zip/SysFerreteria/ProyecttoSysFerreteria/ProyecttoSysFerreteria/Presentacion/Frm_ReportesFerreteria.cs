﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ProyecttoSysFerreteria.Entidad;
using ProyecttoSysFerreteria.Negocios;


namespace ProyecttoSysFerreteria.Presentacion
{
    public partial class Frm_ReportesFerreteria : Form
    {
        public Frm_ReportesFerreteria()
        {
            InitializeComponent();
        }

        private void BtnVentasDia_Click(object sender, EventArgs e)
        {
           
        }

        private void Frm_ReportesFerreteria_Load(object sender, EventArgs e)
        {
            
        }
    }
}
